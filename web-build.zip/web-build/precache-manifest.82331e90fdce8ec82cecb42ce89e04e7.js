self.__precacheManifest = [
  {
    "revision": "658bed93553cd351f672",
    "url": "/static/js/app.c4e44a8b.chunk.js"
  },
  {
    "revision": "12285de5044dece6d261",
    "url": "/static/js/runtime~app.a6639e49.js"
  },
  {
    "revision": "9c02f9d55dad7119bb25",
    "url": "/static/js/2.d63ce04c.chunk.js"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/./fonts/Entypo.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/./fonts/AntDesign.ttf"
  },
  {
    "revision": "ca9ce9ff0676a9b04ef0f8a3ad17dd08",
    "url": "/./fonts/Feather.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "c39278f7abfc798a241551194f55e29f",
    "url": "/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "b70cea0339374107969eb53e5b1f603f",
    "url": "/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "b49ae8ab2dbccb02c4d11caaacf09eab",
    "url": "/./fonts/Fontisto.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/./fonts/Foundation.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/./fonts/Ionicons.ttf"
  },
  {
    "revision": "3c851d60ad5ef3f2fe43ebd263490d78",
    "url": "/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/serve.json"
  },
  {
    "revision": "48c7ed4e7da9792af288a60d7242d615",
    "url": "/expo-service-worker.js"
  },
  {
    "revision": "6dec29a28f17c11551c1ff82f15b7202",
    "url": "/favicon-16.png"
  },
  {
    "revision": "0a04e00a4fe68b7419200e2073db3e3f",
    "url": "/favicon-32.png"
  },
  {
    "revision": "815f35ad2586220fedd0f0e8d19ed92e",
    "url": "/favicon.ico"
  },
  {
    "revision": "06551e7687caf48170065587f87f85dc",
    "url": "/index.html"
  },
  {
    "revision": "2b633e00051b87ba3dce974d3e94496e",
    "url": "/manifest.json"
  },
  {
    "revision": "04cf1ae10e30155ca207400239ec1cbd",
    "url": "/register-service-worker.js"
  }
];